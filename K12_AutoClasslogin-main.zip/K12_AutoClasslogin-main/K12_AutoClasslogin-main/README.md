# K12_AutoClasslogin
A python script automatically login to your k12 profile see if the class is required or optional then join if it is time


